<?php
/**
 * Template Name: Documentation - Components Guide
 *
 * @package WP-Bootstrap
 * @subpackage Default_Theme
 * @since WP-Bootstrap 0.87
 *
 */
get_header();
wp_enqueue_script('prettify-js');
wp_enqueue_style('prettify-css');
wp_enqueue_style('docs-css');
?>
<?php while (have_posts()) : the_post(); ?>

<header class="jumbotron subhead" id="overview">
	<div class="container">
		<h1>
			<?php the_title(); ?></h1>
		<p class="lead">
			Dozens of reusable components built to provide navigation, alerts, popovers, and more.
		</p>
	</div>
</header>

<div class="container">

	<div class="row">

		<div class="span3 bs-docs-sidebar">
			<ul class="nav nav-list bs-docs-sidenav">
				<li>
					<a href="#dropdowns"> <i class="icon-chevron-right"></i>
						Dropdowns
					</a>
				</li>
				<li>
					<a href="#buttonGroups"> <i class="icon-chevron-right"></i>
						Button groups
					</a>
				</li>
				<li>
					<a href="#buttonDropdowns">
						<i class="icon-chevron-right"></i>
						Button dropdowns
					</a>
				</li>
				<li>
					<a href="#navs">
						<i class="icon-chevron-right"></i>
						Navs
					</a>
				</li>
				<li>
					<a href="#navbar">
						<i class="icon-chevron-right"></i>
						Navbar
					</a>
				</li>
				<li>
					<a href="#breadcrumbs">
						<i class="icon-chevron-right"></i>
						Breadcrumbs
					</a>
				</li>
				<li>
					<a href="#pagination">
						<i class="icon-chevron-right"></i>
						Pagination
					</a>
				</li>
				<li>
					<a href="#labels-badges">
						<i class="icon-chevron-right"></i>
						Labels and badges
					</a>
				</li>
				<li>
					<a href="#typography">
						<i class="icon-chevron-right"></i>
						Typography
					</a>
				</li>
				<li>
					<a href="#thumbnails">
						<i class="icon-chevron-right"></i>
						Thumbnails
					</a>
				</li>
				<li>
					<a href="#alerts">
						<i class="icon-chevron-right"></i>
						Alerts
					</a>
				</li>
				<li>
					<a href="#progress">
						<i class="icon-chevron-right"></i>
						Progress bars
					</a>
				</li>
				<li>
					<a href="#media">
						<i class="icon-chevron-right"></i>
						Media object
					</a>
				</li>
				<li>
					<a href="#misc">
						<i class="icon-chevron-right"></i>
						Misc
					</a>
				</li>
			</ul>
		</div>

		<div class="span9">

			<section id="dropdowns">
				<div class="page-header">
					<h1>Dropdown menus</h1>
				</div>

				<h2>Example</h2>
				<p>
					Toggleable, contextual menu for displaying lists of links. Made interactive with the
					<a href="./javascript.html#dropdowns">dropdown JavaScript plugin</a>
					.
				</p>
				<div class="bs-docs-example">
					<div class="dropdown clearfix">
						<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display: block; position: static; margin-bottom: 5px; *width: 180px;">
							<li>
								<a tabindex="-1" href="#">Action</a>
							</li>
							<li>
								<a tabindex="-1" href="#">Another action</a>
							</li>
							<li>
								<a tabindex="-1" href="#">Something else here</a>
							</li>
							<li class="divider"></li>
							<li>
								<a tabindex="-1" href="#">Separated link</a>
							</li>
						</ul>
					</div>
				</div>
				<pre class="prettyprint linenums">
							&lt;ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu"&gt;
							&lt;li&gt;&lt;a tabindex="-1" href="#"&gt;Action&lt;/a&gt;&lt;/li&gt;
							&lt;li&gt;&lt;a tabindex="-1" href="#"&gt;Another action&lt;/a&gt;&lt;/li&gt;
							&lt;li&gt;&lt;a tabindex="-1" href="#"&gt;Something else here&lt;/a&gt;&lt;/li&gt;
							&lt;li class="divider"&gt;&lt;/li&gt;
							&lt;li&gt;&lt;a tabindex="-1" href="#"&gt;Separated link&lt;/a&gt;&lt;/li&gt;
							&lt;/ul&gt;
						</pre>

				<h2>Markup</h2>
				<p>
					Looking at just the dropdown menu, here's the required HTML. You need to wrap the dropdown's trigger and the dropdown menu within
					<code>.dropdown</code>
					, or another element that declares
					<code>position: relative;</code>
					. Then just create the menu.
				</p>

				<pre class="prettyprint linenums">
					&lt;div class="dropdown"&gt;
					&lt;!-- Link or button to toggle dropdown --&gt;
					&lt;ul class="dropdown-menu" role="menu" aria-labelledby="dLabel"&gt;
					&lt;li&gt;&lt;a tabindex="-1" href="#"&gt;Action&lt;/a&gt;&lt;/li&gt;
					&lt;li&gt;&lt;a tabindex="-1" href="#"&gt;Another action&lt;/a&gt;&lt;/li&gt;
					&lt;li&gt;&lt;a tabindex="-1" href="#"&gt;Something else here&lt;/a&gt;&lt;/li&gt;
					&lt;li class="divider"&gt;&lt;/li&gt;
					&lt;li&gt;&lt;a tabindex="-1" href="#"&gt;Separated link&lt;/a&gt;&lt;/li&gt;
					&lt;/ul&gt;
					&lt;/div&gt;
				</pre>

				<h2>Options</h2>
				<p>
					Align menus to the right and add include additional levels of dropdowns.
				</p>

				<h3>Aligning the menus</h3>
				<p>
					Add
					<code>.pull-right</code>
					to a
					<code>.dropdown-menu</code>
					to right align the dropdown menu.
				</p>
				<pre class="prettyprint linenums">
					&lt;ul class="dropdown-menu pull-right" role="menu" aria-labelledby="dLabel"&gt;
					...
					&lt;/ul&gt;
				</pre>

				<h3>Sub menus on dropdowns</h3>
				<p>
					Add an extra level of dropdown menus, appearing on hover like those of OS X, with some simple markup additions. Add
					<code>.dropdown-submenu</code>
					to any
					<code>li</code>
					in an existing dropdown menu for automatic styling.
				</p>
				<div class="bs-docs-example bs-docs-example-submenus">

					<div class="pull-left">
						<p class="muted">Default</p>
						<div class="dropdown clearfix">
							<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu">
								<li>
									<a tabindex="-1" href="#">Action</a>
								</li>
								<li>
									<a tabindex="-1" href="#">Another action</a>
								</li>
								<li>
									<a tabindex="-1" href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li class="dropdown-submenu">
									<a tabindex="-1" href="#">More options</a>
									<ul class="dropdown-menu">
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
									</ul>
								</li>
							</ul>
						</div>
					</div>

					<div class="pull-left">
						<p class="muted">Dropup</p>
						<div class="dropup">
							<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu">
								<li>
									<a tabindex="-1" href="#">Action</a>
								</li>
								<li>
									<a tabindex="-1" href="#">Another action</a>
								</li>
								<li>
									<a tabindex="-1" href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li class="dropdown-submenu">
									<a tabindex="-1" href="#">More options</a>
									<ul class="dropdown-menu">
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
									</ul>
								</li>
							</ul>
						</div>
					</div>

					<div class="pull-left">
						<p class="muted">Left submenu</p>
						<div class="dropdown">
							<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu">
								<li>
									<a tabindex="-1" href="#">Action</a>
								</li>
								<li>
									<a tabindex="-1" href="#">Another action</a>
								</li>
								<li>
									<a tabindex="-1" href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li class="dropdown-submenu pull-left">
									<a tabindex="-1" href="#">More options</a>
									<ul class="dropdown-menu">
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
										<li>
											<a tabindex="-1" href="#">Second level link</a>
										</li>
									</ul>
								</li>
							</ul>
						</div>
					</div>

				</div>
				<pre class="prettyprint linenums">
					&lt;ul class="dropdown-menu" role="menu" aria-labelledby="dLabel"&gt;
					...
					&lt;li class="dropdown-submenu"&gt;
					&lt;a tabindex="-1" href="#"&gt;More options&lt;/a&gt;
					&lt;ul class="dropdown-menu"&gt;
					...
					&lt;/ul&gt;
					&lt;/li&gt;
					&lt;/ul&gt;
				</pre>

			</section>

			<section id="buttonGroups">
				<div class="page-header">
					<h1>Button groups</h1>
				</div>

				<h2>Examples</h2>
				<p>Two basic options, along with two more specific variations.</p>

				<h3>Single button group</h3>
				<p>
					Wrap a series of buttons with
					<code>.btn</code>
					in
					<code>.btn-group</code>
					.
				</p>
				<div class="bs-docs-example">
					<div class="btn-group" style="margin: 9px 0 5px;">
						<button class="btn">Left</button>
						<button class="btn">Middle</button>
						<button class="btn">Right</button>
					</div>
				</div>
				<pre class="prettyprint linenums">
					&lt;div class="btn-group"&gt;
					&lt;button class="btn"&gt;1&lt;/button&gt;
					&lt;button class="btn"&gt;2&lt;/button&gt;
					&lt;button class="btn"&gt;3&lt;/button&gt;
					&lt;/div&gt;
				</pre>

				<h3>Multiple button groups</h3>
				<p>
					Combine sets of
					<code>&lt;div class="btn-group"&gt;</code>
					into a
					<code>&lt;div class="btn-toolbar"&gt;</code>
					for more complex components.
				</p>
				<div class="bs-docs-example">
					<div class="btn-toolbar" style="margin: 0;">
						<div class="btn-group">
							<button class="btn">1</button>
							<button class="btn">2</button>
							<button class="btn">3</button>
							<button class="btn">4</button>
						</div>
						<div class="btn-group">
							<button class="btn">5</button>
							<button class="btn">6</button>
							<button class="btn">7</button>
						</div>
						<div class="btn-group">
							<button class="btn">8</button>
						</div>
					</div>
				</div>
				<pre class="prettyprint linenums">
					&lt;div class="btn-toolbar"&gt;
					&lt;div class="btn-group"&gt;
					...
					&lt;/div&gt;
					&lt;/div&gt;
				</pre>

				<h3>Vertical button groups</h3>
				<p>
					Make a set of buttons appear vertically stacked rather than horizontally.
				</p>
				<div class="bs-docs-example">
					<div class="btn-group btn-group-vertical">
						<button type="button" class="btn">
							<i class="icon-align-left"></i>
						</button>
						<button type="button" class="btn">
							<i class="icon-align-center"></i>
						</button>
						<button type="button" class="btn">
							<i class="icon-align-right"></i>
						</button>
						<button type="button" class="btn">
							<i class="icon-align-justify"></i>
						</button>
					</div>
				</div>
				<pre class="prettyprint linenums">
					&lt;div class="btn-group btn-group-vertical"&gt;
					...
					&lt;/div&gt;
				</pre>

				<hr class="bs-docs-separator">

				<h4>Checkbox and radio flavors</h4>
				<p>
					Button groups can also function as radios, where only one button may be active, or checkboxes, where any number of buttons may be active. View
					<a href="./javascript.html#buttons">the JavaScript docs</a>
					for that.
				</p>

				<h4>Dropdowns in button groups</h4>
				<p>
					<span class="label label-info">Heads up!</span>
					Buttons with dropdowns must be individually wrapped in their own
					<code>.btn-group</code>
					within a
					<code>.btn-toolbar</code>
					for proper rendering.
				</p>
			</section>

			<section id="buttonDropdowns">
				<div class="page-header">
					<h1>Button dropdown menus</h1>
				</div>

				<h2>Overview and examples</h2>
				<p>
					Use any button to trigger a dropdown menu by placing it within a
					<code>.btn-group</code>
					and providing the proper menu markup.
				</p>
				<div class="bs-docs-example">
					<div class="btn-toolbar" style="margin: 0;">
						<div class="btn-group">
							<button class="btn dropdown-toggle" data-toggle="dropdown">
								Action
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
								Action
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
								Danger
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
								Warning
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-success dropdown-toggle" data-toggle="dropdown">
								Success
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-info dropdown-toggle" data-toggle="dropdown">
								Info
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-inverse dropdown-toggle" data-toggle="dropdown">
								Inverse
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
					</div>
					<!-- /btn-toolbar -->
				</div>
				<pre class="prettyprint linenums">
					&lt;div class="btn-group"&gt;
					&lt;a class="btn dropdown-toggle" data-toggle="dropdown" href="#"&gt;
					Action
					&lt;span class="caret"&gt;&lt;/span&gt;
					&lt;/a&gt;
					&lt;ul class="dropdown-menu"&gt;
					&lt;!-- dropdown menu links --&gt;
					&lt;/ul&gt;
					&lt;/div&gt;
				</pre>

				<h3>Works with all button sizes</h3>
				<p>
					Button dropdowns work at any size:
					<code>.btn-large</code>
					,
					<code>.btn-small</code>
					, or
					<code>.btn-mini</code>
					.
				</p>
				<div class="bs-docs-example">
					<div class="btn-toolbar" style="margin: 0;">
						<div class="btn-group">
							<button class="btn btn-large dropdown-toggle" data-toggle="dropdown">
								Large button
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-small dropdown-toggle" data-toggle="dropdown">
								Small button
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-mini dropdown-toggle" data-toggle="dropdown">
								Mini button
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
					</div>
					<!-- /btn-toolbar -->
				</div>

				<h3>Requires JavaScript</h3>
				<p>
					Button dropdowns require the
					<a href="./javascript.html#dropdowns">Bootstrap dropdown plugin</a>
					to function.
				</p>
				<p>
					In some cases&mdash;like mobile&mdash;dropdown menus will extend outside the viewport. You need to resolve the alignment manually or with custom JavaScript.
				</p>

				<hr class="bs-docs-separator">

				<h2>Split button dropdowns</h2>
				<p>
					Building on the button group styles and markup, we can easily create a split button. Split buttons feature a standard action on the left and a dropdown toggle on the right with contextual links.
				</p>
				<div class="bs-docs-example">
					<div class="btn-toolbar" style="margin: 0;">
						<div class="btn-group">
							<button class="btn">Action</button>
							<button class="btn dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-primary">Action</button>
							<button class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-danger">Danger</button>
							<button class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-warning">Warning</button>
							<button class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-success">Success</button>
							<button class="btn btn-success dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-info">Info</button>
							<button class="btn btn-info dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group">
							<button class="btn btn-inverse">Inverse</button>
							<button class="btn btn-inverse dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
					</div>
					<!-- /btn-toolbar -->
				</div>
				<pre class="prettyprint linenums">
					&lt;div class="btn-group"&gt;
					&lt;button class="btn"&gt;Action&lt;/button&gt;
					&lt;button class="btn dropdown-toggle" data-toggle="dropdown"&gt;
					&lt;span class="caret"&gt;&lt;/span&gt;
					&lt;/button&gt;
					&lt;ul class="dropdown-menu"&gt;
					&lt;!-- dropdown menu links --&gt;
					&lt;/ul&gt;
					&lt;/div&gt;
				</pre>

				<h3>Sizes</h3>
				<p>
					Utilize the extra button classes
					<code>.btn-mini</code>
					,
					<code>.btn-small</code>
					, or
					<code>.btn-large</code>
					for sizing.
				</p>
				<div class="bs-docs-example">
					<div class="btn-toolbar">
						<div class="btn-group">
							<button class="btn btn-large">Large action</button>
							<button class="btn btn-large dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
					</div>
					<!-- /btn-toolbar -->
					<div class="btn-toolbar">
						<div class="btn-group">
							<button class="btn btn-small">Small action</button>
							<button class="btn btn-small dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
					</div>
					<!-- /btn-toolbar -->
					<div class="btn-toolbar">
						<div class="btn-group">
							<button class="btn btn-mini">Mini action</button>
							<button class="btn btn-mini dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
					</div>
					<!-- /btn-toolbar -->
				</div>
				<pre class="prettyprint linenums">
					&lt;div class="btn-group"&gt;
					&lt;button class="btn btn-mini"&gt;Action&lt;/button&gt;
					&lt;button class="btn btn-mini dropdown-toggle" data-toggle="dropdown"&gt;
					&lt;span class="caret"&gt;&lt;/span&gt;
					&lt;/button&gt;
					&lt;ul class="dropdown-menu"&gt;
					&lt;!-- dropdown menu links --&gt;
					&lt;/ul&gt;
					&lt;/div&gt;
				</pre>

				<h3>Dropup menus</h3>
				<p>
					Dropdown menus can also be toggled from the bottom up by adding a single class to the immediate parent of
					<code>.dropdown-menu</code>
					. It will flip the direction of the
					<code>.caret</code>
					and reposition the menu itself to move from the bottom up instead of top down.
				</p>
				<div class="bs-docs-example">
					<div class="btn-toolbar" style="margin: 0;">
						<div class="btn-group dropup">
							<button class="btn">Dropup</button>
							<button class="btn dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
						<div class="btn-group dropup">
							<button class="btn primary">Right dropup</button>
							<button class="btn primary dropdown-toggle" data-toggle="dropdown">
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu pull-right">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</div>
						<!-- /btn-group -->
					</div>
				</div>
				<pre class="prettyprint linenums">
					&lt;div class="btn-group dropup"&gt;
					&lt;button class="btn"&gt;Dropup&lt;/button&gt;
					&lt;button class="btn dropdown-toggle" data-toggle="dropdown"&gt;
					&lt;span class="caret"&gt;&lt;/span&gt;
					&lt;/button&gt;
					&lt;ul class="dropdown-menu"&gt;
					&lt;!-- dropdown menu links --&gt;
					&lt;/ul&gt;
					&lt;/div&gt;
				</pre>

			</section>

			<section id="navs">
				<div class="page-header">
					<h1>Navs</small>
				</h1>
			</div>

			<p class="lead">
				Navs available in Bootstrap have shared markup, starting with the base
				<code>.nav</code>
				class, as well as shared states. Swap modifier classes to switch between each style.
			</p>

			<h2>Tabs</h2>
			<p>
				Note the
				<code>.nav-tabs</code>
				class requires the
				<code>.nav</code>
				base class.
			</p>
			<div class="bs-docs-example">
				<ul class="nav nav-tabs">
					<li class="active">
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Profile</a>
					</li>
					<li>
						<a href="#">Messages</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav nav-tabs"&gt;
				&lt;li class="active"&gt;
				&lt;a href="#"&gt;Home&lt;/a&gt;
				&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;...&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;...&lt;/a&gt;&lt;/li&gt;
				&lt;/ul&gt;
			</pre>

			<h2>List</h2>
			<p>
				Swap the tabs class for
				<code>.nav-list</code>
				.
			</p>
			<div class="bs-docs-example">
				<ul class="nav nav-list" style="max-width: 300px;">
					<li class="active">
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Profile</a>
					</li>
					<li>
						<a href="#">Messages</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav nav-list"&gt;
				&lt;li class="active"&gt;
				&lt;a href="#"&gt;Home&lt;/a&gt;
				&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;...&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;...&lt;/a&gt;&lt;/li&gt;
				&lt;/ul&gt;
			</pre>

			<h2>Pills</h2>
			<p>
				Take that same HTML, but use
				<code>.nav-pills</code>
				instead:
			</p>
			<div class="bs-docs-example">
				<ul class="nav nav-pills">
					<li class="active">
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Profile</a>
					</li>
					<li>
						<a href="#">Messages</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav nav-pills"&gt;
				&lt;li class="active"&gt;
				&lt;a href="#"&gt;Home&lt;/a&gt;
				&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;...&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;...&lt;/a&gt;&lt;/li&gt;
				&lt;/ul&gt;
			</pre>
			<p>
				Pills are also vertically stackable. Just add
				<code>.nav-stacked</code>
				.
			</p>
			<div class="bs-docs-example">
				<ul class="nav nav-pills nav-stacked" style="max-width: 300px;">
					<li class="active">
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Profile</a>
					</li>
					<li>
						<a href="#">Messages</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav nav-pills nav-stacked"&gt;
				...
				&lt;/ul&gt;
			</pre>

			<h2>Options</h2>

			<h3>Justified links</h3>
			<p>
				Easily make tabs or pills equal widths of their parent with
				<code>.nav-justified</code>
				.
			</p>
			<div class="bs-docs-example">
				<ul class="nav nav-tabs nav-justified">
					<li class="active">
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Profile</a>
					</li>
					<li>
						<a href="#">Messages</a>
					</li>
				</ul>
				<br>
				<ul class="nav nav-pills nav-justified">
					<li class="active">
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Profile</a>
					</li>
					<li>
						<a href="#">Messages</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav nav-tabs nav-justified"&gt;
				...
				&lt;/ul&gt;

				&lt;ul class="nav nav-pills nav-justified"&gt;
				...
				&lt;/ul&gt;
			</pre>

			<h3>Disabled state</h3>
			<p>
				For any nav component (tabs, pills, or list), add
				<code>.disabled</code>
				for <strong>gray links and no hover effects</strong>
				. Links will remain clickable, however, unless you remove the
				<code>href</code>
				attribute. Alternatively, you could implement custom JavaScript to prevent those clicks.
			</p>
			<div class="bs-docs-example">
				<ul class="nav nav-pills">
					<li>
						<a href="#">Clickable link</a>
					</li>
					<li>
						<a href="#">Clickable link</a>
					</li>
					<li class="disabled">
						<a href="#">Disabled link</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav nav-pills"&gt;
				...
				&lt;li class="disabled"&gt;&lt;a href="#"&gt;Home&lt;/a&gt;&lt;/li&gt;
				...
				&lt;/ul&gt;
			</pre>

			<h3>Component alignment</h3>
			<p>
				To align nav links, use the
				<code>.pull-left</code>
				or
				<code>.pull-right</code>
				utility classes. Both classes will add a CSS float in the specified direction.
			</p>

			<hr class="bs-docs-separator">

			<h2>Dropdowns</h2>
			<p>
				Add dropdown menus with a little extra HTML and the
				<a href="./javascript.html#dropdowns">dropdowns JavaScript plugin</a>
				.
			</p>

			<h3>Tabs with dropdowns</h3>
			<div class="bs-docs-example">
				<ul class="nav nav-tabs">
					<li class="active">
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Help</a>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">
							Dropdown <b class="caret"></b>
						</a>
						<ul class="dropdown-menu">
							<li>
								<a href="#">Action</a>
							</li>
							<li>
								<a href="#">Another action</a>
							</li>
							<li>
								<a href="#">Something else here</a>
							</li>
							<li class="divider"></li>
							<li>
								<a href="#">Separated link</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav nav-tabs"&gt;
				&lt;li class="dropdown"&gt;
				&lt;a class="dropdown-toggle"
				data-toggle="dropdown"
				href="#"&gt;
				Dropdown
				&lt;b class="caret"&gt;&lt;/b&gt;
				&lt;/a&gt;
				&lt;ul class="dropdown-menu"&gt;
				&lt;!-- links --&gt;
				&lt;/ul&gt;
				&lt;/li&gt;
				&lt;/ul&gt;
			</pre>

			<h3>Pills with dropdowns</h3>
			<div class="bs-docs-example">
				<ul class="nav nav-pills">
					<li class="active">
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Help</a>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">
							Dropdown <b class="caret"></b>
						</a>
						<ul class="dropdown-menu">
							<li>
								<a href="#">Action</a>
							</li>
							<li>
								<a href="#">Another action</a>
							</li>
							<li>
								<a href="#">Something else here</a>
							</li>
							<li class="divider"></li>
							<li>
								<a href="#">Separated link</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav nav-pills"&gt;
				&lt;li class="dropdown"&gt;
				&lt;a class="dropdown-toggle"
				data-toggle="dropdown"
				href="#"&gt;
				Dropdown
				&lt;b class="caret"&gt;&lt;/b&gt;
				&lt;/a&gt;
				&lt;ul class="dropdown-menu"&gt;
				&lt;!-- links --&gt;
				&lt;/ul&gt;
				&lt;/li&gt;
				&lt;/ul&gt;
			</pre>

		</section>

		<section id="navbar">
			<div class="page-header">
				<h1>Navbar</h1>
			</div>

			<h2>Basic navbar</h2>
			<p>
				To start, navbars are static (not fixed to the top) and include support for a project name and basic navigation. Place one anywhere within a
				<code>.container</code>
				, which sets the width of your site and content.
			</p>
			<div class="bs-docs-example">
				<div class="navbar">
					<a class="brand" href="#">Title</a>
					<ul class="nav">
						<li class="active">
							<a href="#">Home</a>
						</li>
						<li>
							<a href="#">Link</a>
						</li>
						<li>
							<a href="#">Link</a>
						</li>
					</ul>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="navbar"&gt;
				&lt;a class="brand" href="#"&gt;Title&lt;/a&gt;
				&lt;ul class="nav"&gt;
				&lt;li class="active"&gt;&lt;a href="#"&gt;Home&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;Link&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;Link&lt;/a&gt;&lt;/li&gt;
				&lt;/ul&gt;
				&lt;/div&gt;
			</pre>

			<hr class="bs-docs-separator">

			<h2>Navbar components</h2>

			<h3>Brand</h3>
			<p>
				A simple link to show your brand or project name only requires an anchor tag.
			</p>
			<div class="bs-docs-example">
				<div class="navbar">
					<a class="brand" href="#">Title</a>
				</div>
			</div>
			<pre class="prettyprint linenums">&lt;a class="brand" href="#"&gt;Project name&lt;/a&gt;</pre>

			<h3>Nav links</h3>
			<p>Nav items are simple to add via unordered lists.</p>
			<div class="bs-docs-example">
				<div class="navbar">
					<ul class="nav">
						<li class="active">
							<a href="#">Home</a>
						</li>
						<li>
							<a href="#">Link</a>
						</li>
						<li>
							<a href="#">Link</a>
						</li>
					</ul>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav"&gt;
				&lt;li class="active"&gt;
				&lt;a href="#">Home&lt;/a&gt;
				&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;Link&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;Link&lt;/a&gt;&lt;/li&gt;
				&lt;/ul&gt;
			</pre>
			<p>
				You can easily add dividers to your nav links with an empty list item and a simple class. Just add this between links:
			</p>
			<div class="bs-docs-example">
				<div class="navbar">
					<div class="navbar-inner">
						<ul class="nav">
							<li class="active">
								<a href="#">Home</a>
							</li>
							<li class="divider-vertical"></li>
							<li>
								<a href="#">Link</a>
							</li>
							<li class="divider-vertical"></li>
							<li>
								<a href="#">Link</a>
							</li>
							<li class="divider-vertical"></li>
						</ul>
					</div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="nav"&gt;
				...
				&lt;li class="divider-vertical"&gt;&lt;/li&gt;
				...
				&lt;/ul&gt;
			</pre>

			<h3>Forms</h3>
			<p>
				To properly style and position a form within the navbar, add the appropriate classes as shown below. For a default form, include
				<code>.navbar-form</code>
				and either
				<code>.pull-left</code>
				or
				<code>.pull-right</code>
				to properly align it.
			</p>
			<div class="bs-docs-example">
				<div class="navbar">
					<form class="navbar-form pull-left">
						<input type="text" class="span2">
						<button type="submit" class="btn">Submit</button>
					</form>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;form class="navbar-form pull-left"&gt;
				&lt;input type="text" class="span2"&gt;
				&lt;button type="submit" class="btn"&gt;Submit&lt;/button&gt;
				&lt;/form&gt;
			</pre>

			<h3>Search form</h3>
			<p>
				For a more customized search form, add
				<code>.navbar-search</code>
				to the
				<code>form</code>
				and
				<code>.search-query</code>
				to the input for specialized styles in the navbar.
			</p>
			<div class="bs-docs-example">
				<div class="navbar">
					<form class="navbar-search pull-left">
						<input type="text" class="search-query" placeholder="Search"></form>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;form class="navbar-search pull-left"&gt;
				&lt;input type="text" class="search-query" placeholder="Search"&gt;
				&lt;/form&gt;
			</pre>

			<h3>Component alignment</h3>
			<p>
				Align nav links, search form, or text, use the
				<code>.pull-left</code>
				or
				<code>.pull-right</code>
				utility classes. Both classes will add a CSS float in the specified direction.
			</p>

			<h3>Using dropdowns</h3>
			<p>
				Add dropdowns and dropups to the nav with a bit of markup and the
				<a href="./javascript.html#dropdowns">dropdowns JavaScript plugin</a>
				.
			</p>
			<pre class="prettyprint linenums">
				&lt;ul class="nav"&gt;
				&lt;li class="dropdown"&gt;
				&lt;a href="#" class="dropdown-toggle" data-toggle="dropdown">
				Account
				&lt;b class="caret"&gt;&lt;/b&gt;
				&lt;/a&gt;
				&lt;ul class="dropdown-menu"&gt;
				...
				&lt;/ul&gt;
				&lt;/li&gt;
				&lt;/ul&gt;
			</pre>
			<p>
				Visit the
				<a href="./javascript.html#dropdowns">JavaScript dropdowns documentation</a>
				for more markup and information on calling dropdowns.
			</p>

			<h3>Text</h3>
			<p>
				Wrap strings of text in an element with
				<code>.navbar-text</code>
				, usually on a
				<code>&lt;p&gt;</code>
				tag for proper leading and color.
			</p>

			<hr class="bs-docs-separator">

			<h2>Optional display variations</h2>
			<p>
				Fix the navbar to the top or bottom of the viewport with an additional class on the outermost div,
				<code>.navbar</code>
				.
			</p>

			<h3>Fixed to top</h3>
			<p>
				Add
				<code>.navbar-fixed-top</code>
				and remember to account for the hidden area underneath it by adding at least 40px
				<code>padding</code>
				to the
				<code>&lt;body&gt;</code>
				. Be sure to add this after the core Bootstrap CSS and before the optional responsive CSS.
			</p>
			<div class="bs-docs-example bs-navbar-top-example">
				<div class="navbar navbar-fixed-top" style="position: absolute;">
					<div class="container" style="width: auto;">
						<a class="brand" href="#">Title</a>
						<ul class="nav">
							<li class="active">
								<a href="#">Home</a>
							</li>
							<li>
								<a href="#">Link</a>
							</li>
							<li>
								<a href="#">Link</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="navbar navbar-fixed-top"&gt;
				...
				&lt;/div&gt;
			</pre>

			<h3>Fixed to bottom</h3>
			<p>
				Add
				<code>.navbar-fixed-bottom</code>
				instead.
			</p>
			<div class="bs-docs-example bs-navbar-bottom-example">
				<div class="navbar navbar-fixed-bottom" style="position: absolute;">
					<div class="container" style="width: auto;">
						<a class="brand" href="#">Title</a>
						<ul class="nav">
							<li class="active">
								<a href="#">Home</a>
							</li>
							<li>
								<a href="#">Link</a>
							</li>
							<li>
								<a href="#">Link</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="navbar navbar-fixed-bottom"&gt;
				...
				&lt;/div&gt;
			</pre>

			<h3>Static top navbar</h3>
			<p>
				Create a full-width navbar that scrolls away with the page by adding
				<code>.navbar-static-top</code>
				. Unlike the
				<code>.navbar-fixed-top</code>
				class, you do not need to change any padding on the
				<code>body</code>
				.
			</p>
			<div class="bs-docs-example bs-navbar-top-example">
				<div class="navbar navbar-static-top" style="margin: -1px -1px 0;">
					<div class="container" style="width: auto;">
						<a class="brand" href="#">Title</a>
						<ul class="nav">
							<li class="active">
								<a href="#">Home</a>
							</li>
							<li>
								<a href="#">Link</a>
							</li>
							<li>
								<a href="#">Link</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="navbar navbar-static-top"&gt;
				...
				&lt;/div&gt;
			</pre>

			<hr class="bs-docs-separator">

			<h2>Responsive navbar</h2>
			<p>
				To implement a collapsing responsive navbar, wrap your navbar content in a containing div,
				<code>.nav-collapse.collapse</code>
				, and add the navbar toggle button,
				<code>.btn-navbar</code>
				.
			</p>
			<div class="bs-docs-example">
				<div class="navbar">
					<div class="container">
						<a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</a>
						<a class="brand" href="#">Title</a>
						<div class="nav-collapse collapse navbar-responsive-collapse">
							<ul class="nav">
								<li class="active">
									<a href="#">Home</a>
								</li>
								<li>
									<a href="#">Link</a>
								</li>
								<li>
									<a href="#">Link</a>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">
										Dropdown
										<b class="caret"></b>
									</a>
									<ul class="dropdown-menu">
										<li>
											<a href="#">Action</a>
										</li>
										<li>
											<a href="#">Another action</a>
										</li>
										<li>
											<a href="#">Something else here</a>
										</li>
										<li class="divider"></li>
										<li class="nav-header">Nav header</li>
										<li>
											<a href="#">Separated link</a>
										</li>
										<li>
											<a href="#">One more separated link</a>
										</li>
									</ul>
								</li>
							</ul>
							<form class="navbar-search pull-left" action="">
								<input type="text" class="search-query span2" placeholder="Search"></form>
							<ul class="nav pull-right">
								<li>
									<a href="#">Link</a>
								</li>
								<li class="divider-vertical"></li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">
										Dropdown
										<b class="caret"></b>
									</a>
									<ul class="dropdown-menu">
										<li>
											<a href="#">Action</a>
										</li>
										<li>
											<a href="#">Another action</a>
										</li>
										<li>
											<a href="#">Something else here</a>
										</li>
										<li class="divider"></li>
										<li>
											<a href="#">Separated link</a>
										</li>
									</ul>
								</li>
							</ul>
						</div>
						<!-- /.nav-collapse -->
					</div>

				</div>
				<!-- /navbar -->
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="navbar"&gt;
				&lt;div class="container"&gt;

				&lt;!-- .btn-navbar is used as the toggle for collapsed navbar content --&gt;
				&lt;a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"&gt;
				&lt;span class="icon-bar"&gt;&lt;/span&gt;
				&lt;span class="icon-bar"&gt;&lt;/span&gt;
				&lt;span class="icon-bar"&gt;&lt;/span&gt;
				&lt;/a&gt;

				&lt;!-- Be sure to leave the brand out there if you want it shown --&gt;
				&lt;a class="brand" href="#"&gt;Project name&lt;/a&gt;

				&lt;!-- Everything you want hidden at 940px or less, place within here --&gt;
				&lt;div class="nav-collapse collapse"&gt;
				&lt;!-- .nav, .navbar-search, .navbar-form, etc --&gt;
				&lt;/div&gt;

				&lt;/div&gt;
				&lt;/div&gt;
			</pre>
			<div class="alert alert-info"> <strong>Heads up!</strong>
				The responsive navbar requires the
				<a href="./javascript.html#collapse">collapse plugin</a>
				and
				<a href="./scaffolding.html#responsive">responsive Bootstrap CSS file</a>
				.
			</div>

			<hr class="bs-docs-separator">

			<h2>Inverted variation</h2>
			<p>
				Modify the look of the navbar by adding
				<code>.navbar-inverse</code>
				.
			</p>
			<div class="bs-docs-example">
				<div class="navbar navbar-inverse" style="position: static;">
					<div class="container">
						<a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</a>
						<a class="brand" href="#">Title</a>
						<div class="nav-collapse collapse navbar-inverse-collapse">
							<ul class="nav">
								<li class="active">
									<a href="#">Home</a>
								</li>
								<li>
									<a href="#">Link</a>
								</li>
								<li>
									<a href="#">Link</a>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">
										Dropdown
										<b class="caret"></b>
									</a>
									<ul class="dropdown-menu">
										<li>
											<a href="#">Action</a>
										</li>
										<li>
											<a href="#">Another action</a>
										</li>
										<li>
											<a href="#">Something else here</a>
										</li>
										<li class="divider"></li>
										<li class="nav-header">Nav header</li>
										<li>
											<a href="#">Separated link</a>
										</li>
										<li>
											<a href="#">One more separated link</a>
										</li>
									</ul>
								</li>
							</ul>
							<form class="navbar-search pull-left" action="">
								<input type="text" class="search-query span2" placeholder="Search"></form>
							<ul class="nav pull-right">
								<li>
									<a href="#">Link</a>
								</li>
								<li class="divider-vertical"></li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">
										Dropdown
										<b class="caret"></b>
									</a>
									<ul class="dropdown-menu">
										<li>
											<a href="#">Action</a>
										</li>
										<li>
											<a href="#">Another action</a>
										</li>
										<li>
											<a href="#">Something else here</a>
										</li>
										<li class="divider"></li>
										<li>
											<a href="#">Separated link</a>
										</li>
									</ul>
								</li>
							</ul>
						</div>
						<!-- /.nav-collapse -->
					</div>
				</div>
				<!-- /navbar -->
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="navbar navbar-inverse"&gt;
				...
				&lt;/div&gt;
			</pre>

		</section>

		<section id="breadcrumbs">
			<div class="page-header">
				<h1>
					Breadcrumbs
					<small></small>
				</h1>
			</div>

			<h2>Examples</h2>
			<p>
				A single example shown as it might be displayed across multiple pages.
			</p>
			<div class="bs-docs-example">
				<ul class="breadcrumb">
					<li class="active">Home</li>
				</ul>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a>
					</li>
					<li class="active">Library</li>
				</ul>
				<ul class="breadcrumb" style="margin-bottom: 5px;">
					<li>
						<a href="#">Home</a>
					</li>
					<li>
						<a href="#">Library</a>
					</li>
					<li class="active">Data</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="breadcrumb"&gt;
				&lt;li&gt;&lt;a href="#"&gt;Home&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;Library&lt;/a&gt;&lt;/li&gt;
				&lt;li class="active"&gt;Data&lt;/li&gt;
				&lt;/ul&gt;
			</pre>

		</section>

		<section id="pagination">
			<div class="page-header">
				<h1>
					Pagination
					<small>Two options for paging through content</small>
				</h1>
			</div>

			<h2>Standard pagination</h2>
			<p>
				Simple pagination inspired by Rdio, great for apps and search results. The large block is hard to miss, easily scalable, and provides large click areas.
			</p>
			<div class="bs-docs-example">
				<div class="pagination">
					<ul>
						<li>
							<a href="#">&laquo;</a>
						</li>
						<li>
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">4</a>
						</li>
						<li>
							<a href="#">5</a>
						</li>
						<li>
							<a href="#">&raquo;</a>
						</li>
					</ul>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="pagination"&gt;
				&lt;ul&gt;
				&lt;li&gt;&lt;a href="#"&gt;Prev&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;1&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;2&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;3&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;4&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;Next&lt;/a&gt;&lt;/li&gt;
				&lt;/ul&gt;
				&lt;/div&gt;
			</pre>

			<hr class="bs-docs-separator">

			<h2>Options</h2>

			<h3>Disabled and active states</h3>
			<p>
				Links are customizable for different circumstances. Use
				<code>.disabled</code>
				for unclickable links and
				<code>.active</code>
				to indicate the current page.
			</p>
			<div class="bs-docs-example">
				<div class="pagination pagination-centered">
					<ul>
						<li class="disabled">
							<a href="#">&laquo;</a>
						</li>
						<li class="active">
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">4</a>
						</li>
						<li>
							<a href="#">5</a>
						</li>
						<li>
							<a href="#">&raquo;</a>
						</li>
					</ul>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="pagination"&gt;
				&lt;ul&gt;
				&lt;li class="disabled"&gt;&lt;a href="#"&gt;Prev&lt;/a&gt;&lt;/li&gt;
				&lt;li class="active"&gt;&lt;a href="#"&gt;1&lt;/a&gt;&lt;/li&gt;
				...
				&lt;/ul&gt;
				&lt;/div&gt;
			</pre>
			<p>
				You can optionally swap out active or disabled anchors for spans to remove click functionality while retaining intended styles.
			</p>
			<pre class="prettyprint linenums">
				&lt;div class="pagination"&gt;
				&lt;ul&gt;
				&lt;li class="disabled"&gt;&lt;span&gt;Prev&lt;/span&gt;&lt;/li&gt;
				&lt;li class="active"&gt;&lt;span&gt;1&lt;/span&gt;&lt;/li&gt;
				...
				&lt;/ul&gt;
				&lt;/div&gt;
			</pre>

			<h3>Sizes</h3>
			<p>
				Fancy larger or smaller pagination? Add
				<code>.pagination-large</code>
				,
				<code>.pagination-small</code>
				, or
				<code>.pagination-mini</code>
				for additional sizes.
			</p>
			<div class="bs-docs-example">
				<div class="pagination pagination-large">
					<ul>
						<li>
							<a href="#">&laquo;</a>
						</li>
						<li>
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">4</a>
						</li>
						<li>
							<a href="#">5</a>
						</li>
						<li>
							<a href="#">&raquo;</a>
						</li>
					</ul>
				</div>
				<div class="pagination">
					<ul>
						<li>
							<a href="#">&laquo;</a>
						</li>
						<li>
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">4</a>
						</li>
						<li>
							<a href="#">5</a>
						</li>
						<li>
							<a href="#">&raquo;</a>
						</li>
					</ul>
				</div>
				<div class="pagination pagination-small">
					<ul>
						<li>
							<a href="#">&laquo;</a>
						</li>
						<li>
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">4</a>
						</li>
						<li>
							<a href="#">5</a>
						</li>
						<li>
							<a href="#">&raquo;</a>
						</li>
					</ul>
				</div>
				<div class="pagination pagination-mini">
					<ul>
						<li>
							<a href="#">&laquo;</a>
						</li>
						<li>
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">4</a>
						</li>
						<li>
							<a href="#">5</a>
						</li>
						<li>
							<a href="#">&raquo;</a>
						</li>
					</ul>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="pagination pagination-large"&gt;
				&lt;ul&gt;
				...
				&lt;/ul&gt;
				&lt;/div&gt;
				&lt;div class="pagination"&gt;
				&lt;ul&gt;
				...
				&lt;/ul&gt;
				&lt;/div&gt;
				&lt;div class="pagination pagination-small"&gt;
				&lt;ul&gt;
				...
				&lt;/ul&gt;
				&lt;/div&gt;
				&lt;div class="pagination pagination-mini"&gt;
				&lt;ul&gt;
				...
				&lt;/ul&gt;
				&lt;/div&gt;
			</pre>

			<h3>Alignment</h3>
			<p>
				Add one of two optional classes to change the alignment of pagination links:
				<code>.pagination-centered</code>
				and
				<code>.pagination-right</code>
				.
			</p>
			<div class="bs-docs-example">
				<div class="pagination pagination-centered">
					<ul>
						<li>
							<a href="#">&laquo;</a>
						</li>
						<li>
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">4</a>
						</li>
						<li>
							<a href="#">5</a>
						</li>
						<li>
							<a href="#">&raquo;</a>
						</li>
					</ul>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="pagination pagination-centered"&gt;
				...
				&lt;/div&gt;
			</pre>
			<div class="bs-docs-example">
				<div class="pagination pagination-right">
					<ul>
						<li>
							<a href="#">&laquo;</a>
						</li>
						<li>
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">4</a>
						</li>
						<li>
							<a href="#">5</a>
						</li>
						<li>
							<a href="#">&raquo;</a>
						</li>
					</ul>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="pagination pagination-right"&gt;
				...
				&lt;/div&gt;
			</pre>

			<hr class="bs-docs-separator">

			<h2>Pager</h2>
			<p>
				Quick previous and next links for simple pagination implementations with light markup and styles. It's great for simple sites like blogs or magazines.
			</p>

			<h3>Default example</h3>
			<p>By default, the pager centers links.</p>
			<div class="bs-docs-example">
				<ul class="pager">
					<li>
						<a href="#">Previous</a>
					</li>
					<li>
						<a href="#">Next</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="pager"&gt;
				&lt;li&gt;&lt;a href="#"&gt;Previous&lt;/a&gt;&lt;/li&gt;
				&lt;li&gt;&lt;a href="#"&gt;Next&lt;/a&gt;&lt;/li&gt;
				&lt;/ul&gt;
			</pre>

			<h3>Aligned links</h3>
			<p>Alternatively, you can align each link to the sides:</p>
			<div class="bs-docs-example">
				<ul class="pager">
					<li class="previous">
						<a href="#">&larr; Older</a>
					</li>
					<li class="next">
						<a href="#">Newer &rarr;</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="pager"&gt;
				&lt;li class="previous"&gt;
				&lt;a href="#"&gt;&amp;larr; Older&lt;/a&gt;
				&lt;/li&gt;
				&lt;li class="next"&gt;
				&lt;a href="#"&gt;Newer &amp;rarr;&lt;/a&gt;
				&lt;/li&gt;
				&lt;/ul&gt;
			</pre>

			<h3>Optional disabled state</h3>
			<p>
				Pager links also use the general
				<code>.disabled</code>
				utility class from the pagination.
			</p>
			<div class="bs-docs-example">
				<ul class="pager">
					<li class="previous disabled">
						<a href="#">&larr; Older</a>
					</li>
					<li class="next">
						<a href="#">Newer &rarr;</a>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="pager"&gt;
				&lt;li class="previous disabled"&gt;
				&lt;a href="#"&gt;&amp;larr; Older&lt;/a&gt;
				&lt;/li&gt;
				...
				&lt;/ul&gt;
			</pre>

		</section>

		<section id="labels-badges">
			<div class="page-header">
				<h1>Labels and badges</h1>
			</div>
			<h3>Labels</h3>
			<table class="table table-bordered table-striped">
				<thead>
					<tr>
						<th>Labels</th>
						<th>Markup</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>
							<span class="label">Default</span>
						</td>
						<td>
							<code>&lt;span class="label"&gt;Default&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>
							<span class="label label-success">Success</span>
						</td>
						<td>
							<code>&lt;span class="label label-success"&gt;Success&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>
							<span class="label label-warning">Warning</span>
						</td>
						<td>
							<code>&lt;span class="label label-warning"&gt;Warning&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>
							<span class="label label-danger">Danger</span>
						</td>
						<td>
							<code>&lt;span class="label label-danger"&gt;Danger&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>
							<span class="label label-info">Info</span>
						</td>
						<td>
							<code>&lt;span class="label label-info"&gt;Info&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>
							<span class="label label-inverse">Inverse</span>
						</td>
						<td>
							<code>&lt;span class="label label-inverse"&gt;Inverse&lt;/span&gt;</code>
						</td>
					</tr>
				</tbody>
			</table>

			<h3>Badges</h3>
			<table class="table table-bordered table-striped">
				<thead>
					<tr>
						<th>Name</th>
						<th>Example</th>
						<th>Markup</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Default</td>
						<td>
							<span class="badge">1</span>
						</td>
						<td>
							<code>&lt;span class="badge"&gt;1&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>Success</td>
						<td>
							<span class="badge badge-success">2</span>
						</td>
						<td>
							<code>&lt;span class="badge badge-success"&gt;2&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>Warning</td>
						<td>
							<span class="badge badge-warning">4</span>
						</td>
						<td>
							<code>&lt;span class="badge badge-warning"&gt;4&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>Important</td>
						<td>
							<span class="badge badge-danger">6</span>
						</td>
						<td>
							<code>&lt;span class="badge badge-danger"&gt;6&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>Info</td>
						<td>
							<span class="badge badge-info">8</span>
						</td>
						<td>
							<code>&lt;span class="badge badge-info"&gt;8&lt;/span&gt;</code>
						</td>
					</tr>
					<tr>
						<td>Inverse</td>
						<td>
							<span class="badge badge-inverse">10</span>
						</td>
						<td>
							<code>&lt;span class="badge badge-inverse"&gt;10&lt;/span&gt;</code>
						</td>
					</tr>
				</tbody>
			</table>

			<h3>Easily collapsible</h3>
			<p>
				For easy implementation, labels and badges will simply collapse (via CSS's
				<code>:empty</code>
				selector) when no content exists within.
			</p>

		</section>

		<section id="typography">
			<div class="page-header">
				<h1>Typographic components</h1>
			</div>

			<h2>Hero unit</h2>
			<p>
				A lightweight, flexible component to showcase key content on your site. It works well on marketing and content-heavy sites.
			</p>
			<div class="bs-docs-example">
				<div class="hero-unit">
					<h1>Hello, world!</h1>
					<p>
						This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.
					</p>
					<p>
						<a class="btn btn-primary btn-large">Learn more</a>
					</p>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="hero-unit"&gt;
				&lt;h1&gt;Heading&lt;/h1&gt;
				&lt;p&gt;Tagline&lt;/p&gt;
				&lt;p&gt;
				&lt;a class="btn btn-primary btn-large"&gt;
				Learn more
				&lt;/a&gt;
				&lt;/p&gt;
				&lt;/div&gt;
			</pre>

			<h2>Page header</h2>
			<p>
				A simple shell for an
				<code>h1</code>
				to appropriately space out and segment sections of content on a page. It can utilize the
				<code>h1</code>
				's default
				<code>small</code>
				, element as well most other components (with additional styles).
			</p>
			<div class="bs-docs-example">
				<div class="page-header">
					<h1>
						Example page header
						<small>Subtext for header</small>
					</h1>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="page-header"&gt;
				&lt;h1&gt;Example page header &lt;small&gt;Subtext for header&lt;/small&gt;&lt;/h1&gt;
				&lt;/div&gt;
			</pre>

		</section>

		<section id="thumbnails">
			<div class="page-header">
				<h1>
					Thumbnails
					<small>Grids of images, videos, text, and more</small>
				</h1>
			</div>

			<h3>Default thumbnails</h3>
			<p>
				By default, Bootstrap's thumbnails are designed to showcase linked images with minimal required markup.
			</p>
			<div class="bs-docs-example">
				<div class="row">
					<div class="span3">
						<a href="#" class="thumbnail">
							<img data-src="holder.js/260x180" alt=""></a>
					</div>
					<div class="span3">
						<a href="#" class="thumbnail">
							<img data-src="holder.js/260x180" alt=""></a>
					</div>
					<div class="span3">
						<a href="#" class="thumbnail">
							<img data-src="holder.js/260x180" alt=""></a>
					</div>
					<div class="span3">
						<a href="#" class="thumbnail">
							<img data-src="holder.js/260x180" alt=""></a>
					</div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="row"&gt;
				&lt;div class="span3"&gt;
				&lt;a href="#" class="thumbnail"&gt;
				&lt;img src="holder.js/260x180" alt=""&gt;
				&lt;/a&gt;
				&lt;/div&gt;
				...
				&lt;/div&gt;
			</pre>

			<h3>Custom content thumbnails</h3>
			<p>
				With a bit of extra markup, it's possible to add any kind of HTML content like headings, paragraphs, or buttons into thumbnails.
			</p>
			<div class="bs-docs-example">
				<div class="row">
					<div class="span4">
						<div class="thumbnail">
							<img data-src="holder.js/300x200" alt="">
							<div class="caption">
								<h3>Thumbnail label</h3>
								<p>
									Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
								</p>
								<p>
									<a href="#" class="btn btn-primary">Action</a>
									<a href="#" class="btn">Action</a>
								</p>
							</div>
						</div>
					</div>
					<div class="span4">
						<div class="thumbnail">
							<img data-src="holder.js/300x200" alt="">
							<div class="caption">
								<h3>Thumbnail label</h3>
								<p>
									Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
								</p>
								<p>
									<a href="#" class="btn btn-primary">Action</a>
									<a href="#" class="btn">Action</a>
								</p>
							</div>
						</div>
					</div>
					<div class="span4">
						<div class="thumbnail">
							<img data-src="holder.js/300x200" alt="">
							<div class="caption">
								<h3>Thumbnail label</h3>
								<p>
									Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
								</p>
								<p>
									<a href="#" class="btn btn-primary">Action</a>
									<a href="#" class="btn">Action</a>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="row"&gt;
				&lt;div class="span4"&gt;
				&lt;div class="thumbnail"&gt;
				&lt;img data-src="holder.js/300x200" alt=""&gt;
				&lt;h3&gt;Thumbnail label&lt;/h3&gt;
				&lt;p&gt;Thumbnail caption...&lt;/p&gt;
				&lt;/div&gt;
				&lt;/div&gt;
				...
				&lt;/div&gt;
			</pre>

		</section>

		<section id="alerts">
			<div class="page-header">
				<h1>
					Alerts
					<small>Styles for success, warning, and error messages</small>
				</h1>
			</div>

			<h2>Default alert</h2>
			<p>
				Wrap any text and an optional dismiss button in
				<code>.alert</code>
				for a basic warning alert message.
			</p>
			<div class="bs-docs-example">
				<div class="alert">
					<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Warning!</strong>
					Best check yo self, you're not looking too good.
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="alert"&gt;
				&lt;button type="button" class="close" data-dismiss="alert"&gt;&amp;times;&lt;/button&gt;
				&lt;strong&gt;Warning!&lt;/strong&gt; Best check yo self, you're not looking too good.
				&lt;/div&gt;
			</pre>

			<h3>Dismiss buttons</h3>
			<p>
				Mobile Safari and Mobile Opera browsers, in addition to the
				<code>data-dismiss="alert"</code>
				attribute, require an
				<code>href="#"</code>
				for the dismissal of alerts when using an
				<code>&lt;a&gt;</code>
				tag.
			</p>
			<pre class="prettyprint linenums">&lt;a href="#" class="close" data-dismiss="alert"&gt;&amp;times;&lt;/a&gt;</pre>
			<p>
				Alternatively, you may use a
				<code>&lt;button&gt;</code>
				element with the data attribute, which we have opted to do for our docs. When using
				<code>&lt;button&gt;</code>
				, you must include
				<code>type="button"</code>
				or your forms may not submit.
			</p>
			<pre class="prettyprint linenums">&lt;button type="button" class="close" data-dismiss="alert"&gt;&amp;times;&lt;/button&gt;</pre>

			<h3>Dismiss alerts via JavaScript</h3>
			<p>
				Use the
				<a href="./javascript.html#alerts">alerts jQuery plugin</a>
				for quick and easy dismissal of alerts.
			</p>

			<hr class="bs-docs-separator">

			<h2>Options</h2>
			<p>
				For longer messages, increase the padding on the top and bottom of the alert wrapper by adding
				<code>.alert-block</code>
				.
			</p>
			<div class="bs-docs-example">
				<div class="alert alert-block">
					<button type="button" class="close" data-dismiss="alert">&times;</button>
					<h4>Warning!</h4>
					<p>
						Best check yo self, you're not looking too good. Nulla vitae elit libero, a pharetra augue. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.
					</p>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="alert alert-block"&gt;
				&lt;button type="button" class="close" data-dismiss="alert"&gt;&amp;times;&lt;/button&gt;
				&lt;h4&gt;Warning!&lt;/h4&gt;
				Best check yo self, you're not...
				&lt;/div&gt;
			</pre>

			<hr class="bs-docs-separator">

			<h2>Contextual alternatives</h2>
			<p>Add optional classes to change an alert's connotation.</p>

			<h3>Error or danger</h3>
			<div class="bs-docs-example">
				<div class="alert alert-error">
					<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Oh snap!</strong>
					Change a few things up and try submitting again.
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="alert alert-error"&gt;
				...
				&lt;/div&gt;
			</pre>

			<h3>Success</h3>
			<div class="bs-docs-example">
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Well done!</strong>
					You successfully read this important alert message.
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="alert alert-success"&gt;
				...
				&lt;/div&gt;
			</pre>

			<h3>Information</h3>
			<div class="bs-docs-example">
				<div class="alert alert-info">
					<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Heads up!</strong>
					This alert needs your attention, but it's not super important.
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="alert alert-info"&gt;
				...
				&lt;/div&gt;
			</pre>

		</section>

		<section id="progress">
			<div class="page-header">
				<h1>
					Progress bars
					<small>For loading, redirecting, or action status</small>
				</h1>
			</div>

			<h2>Examples and markup</h2>

			<h3>Basic</h3>
			<p>Default progress bar with a vertical gradient.</p>
			<div class="bs-docs-example">
				<div class="progress">
					<div class="bar" style="width: 60%;"></div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="progress"&gt;
				&lt;div class="bar" style="width: 60%;"&gt;&lt;/div&gt;
				&lt;/div&gt;
			</pre>

			<h3>Striped</h3>
			<p>
				Uses a gradient to create a striped effect. Not available in IE8.
			</p>
			<div class="bs-docs-example">
				<div class="progress progress-striped">
					<div class="bar" style="width: 20%;"></div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="progress progress-striped"&gt;
				&lt;div class="bar" style="width: 20%;"&gt;&lt;/div&gt;
				&lt;/div&gt;
			</pre>

			<h3>Animated</h3>
			<p>
				Add
				<code>.active</code>
				to
				<code>.progress-striped</code>
				to animate the stripes right to left. Not available in all versions of IE.
			</p>
			<div class="bs-docs-example">
				<div class="progress progress-striped active">
					<div class="bar" style="width: 45%"></div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="progress progress-striped active"&gt;
				&lt;div class="bar" style="width: 40%;"&gt;&lt;/div&gt;
				&lt;/div&gt;
			</pre>

			<h3>Stacked</h3>
			<p>
				Place multiple bars into the same
				<code>.progress</code>
				to stack them.
			</p>
			<div class="bs-docs-example">
				<div class="progress">
					<div class="bar bar-success" style="width: 35%"></div>
					<div class="bar bar-warning" style="width: 20%"></div>
					<div class="bar bar-danger" style="width: 10%"></div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="progress"&gt;
				&lt;div class="bar bar-success" style="width: 35%;"&gt;&lt;/div&gt;
				&lt;div class="bar bar-warning" style="width: 20%;"&gt;&lt;/div&gt;
				&lt;div class="bar bar-danger" style="width: 10%;"&gt;&lt;/div&gt;
				&lt;/div&gt;
			</pre>

			<hr class="bs-docs-separator">

			<h2>Options</h2>

			<h3>Additional colors</h3>
			<p>
				Progress bars use some of the same button and alert classes for consistent styles.
			</p>
			<div class="bs-docs-example">
				<div class="progress progress-info" style="margin-bottom: 9px;">
					<div class="bar" style="width: 20%"></div>
				</div>
				<div class="progress progress-success" style="margin-bottom: 9px;">
					<div class="bar" style="width: 40%"></div>
				</div>
				<div class="progress progress-warning" style="margin-bottom: 9px;">
					<div class="bar" style="width: 60%"></div>
				</div>
				<div class="progress progress-danger">
					<div class="bar" style="width: 80%"></div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="progress progress-info"&gt;
				&lt;div class="bar" style="width: 20%"&gt;&lt;/div&gt;
				&lt;/div&gt;
				&lt;div class="progress progress-success"&gt;
				&lt;div class="bar" style="width: 40%"&gt;&lt;/div&gt;
				&lt;/div&gt;
				&lt;div class="progress progress-warning"&gt;
				&lt;div class="bar" style="width: 60%"&gt;&lt;/div&gt;
				&lt;/div&gt;
				&lt;div class="progress progress-danger"&gt;
				&lt;div class="bar" style="width: 80%"&gt;&lt;/div&gt;
				&lt;/div&gt;
			</pre>

			<h3>Striped bars</h3>
			<p>
				Similar to the solid colors, we have varied striped progress bars.
			</p>
			<div class="bs-docs-example">
				<div class="progress progress-info progress-striped" style="margin-bottom: 9px;">
					<div class="bar" style="width: 20%"></div>
				</div>
				<div class="progress progress-success progress-striped" style="margin-bottom: 9px;">
					<div class="bar" style="width: 40%"></div>
				</div>
				<div class="progress progress-warning progress-striped" style="margin-bottom: 9px;">
					<div class="bar" style="width: 60%"></div>
				</div>
				<div class="progress progress-danger progress-striped">
					<div class="bar" style="width: 80%"></div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="progress progress-info progress-striped"&gt;
				&lt;div class="bar" style="width: 20%"&gt;&lt;/div&gt;
				&lt;/div&gt;
				&lt;div class="progress progress-success progress-striped"&gt;
				&lt;div class="bar" style="width: 40%"&gt;&lt;/div&gt;
				&lt;/div&gt;
				&lt;div class="progress progress-warning progress-striped"&gt;
				&lt;div class="bar" style="width: 60%"&gt;&lt;/div&gt;
				&lt;/div&gt;
				&lt;div class="progress progress-danger progress-striped"&gt;
				&lt;div class="bar" style="width: 80%"&gt;&lt;/div&gt;
				&lt;/div&gt;
			</pre>

			<hr class="bs-docs-separator">

			<h2>Browser support</h2>
			<p>
				Progress bars use CSS3 gradients, transitions, and animations to achieve all their effects. These features are not supported in IE8-9 or older versions of Firefox.
			</p>
			<p>
				Versions earlier than Internet Explorer 10 and Opera 12 do not support animations.
			</p>

		</section>

		<!-- Media object
	================================================== -->
		<section id="media">
			<div class="page-header">
				<h1>Media object</h1>
			</div>
			<p class="lead">
				Abstract object styles for building various types of components (like blog comments, Tweets, etc) that feature a left- or right-aligned image alongside textual content.
			</p>

			<h2>Default example</h2>
			<p>
				The default media allow to float a media object (images, video, audio) to the left or right of a content block.
			</p>
			<div class="bs-docs-example">
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" data-src="holder.js/64x64"></a>
					<div class="media-body">
						<h4 class="media-heading">Media heading</h4>
						Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
					</div>
				</div>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" data-src="holder.js/64x64"></a>
					<div class="media-body">
						<h4 class="media-heading">Media heading</h4>
						Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
						<div class="media">
							<a class="pull-left" href="#">
								<img class="media-object" data-src="holder.js/64x64"></a>
							<div class="media-body">
								<h4 class="media-heading">Media heading</h4>
								Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
							</div>
						</div>
					</div>
				</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="media"&gt;
				&lt;a class="pull-left" href="#"&gt;
				&lt;img class="media-object" data-src="holder.js/64x64"&gt;
				&lt;/a&gt;
				&lt;div class="media-body"&gt;
				&lt;h4 class="media-heading"&gt;Media heading&lt;/h4&gt;
				...

				&lt;!-- Nested media object --&gt;
				&lt;div class="media"&gt;
				...
				&lt;/div&gt;
				&lt;/div&gt;
				&lt;/div&gt;
			</pre>

			<hr class="bs-docs-separator">

			<h2>Media list</h2>
			<p>
				With a bit of extra markup, you can use media inside list (useful for comment threads or articles lists).
			</p>
			<div class="bs-docs-example">
				<ul class="media-list">
					<li class="media">
						<a class="pull-left" href="#">
							<img class="media-object" data-src="holder.js/64x64"></a>
						<div class="media-body">
							<h4 class="media-heading">Media heading</h4>
							<p>
								Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
							</p>
							<!-- Nested media object -->
							<div class="media">
								<a class="pull-left" href="#">
									<img class="media-object" data-src="holder.js/64x64"></a>
								<div class="media-body">
									<h4 class="media-heading">Nested media heading</h4>
									Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
									<!-- Nested media object -->
									<div class="media">
										<a class="pull-left" href="#">
											<img class="media-object" data-src="holder.js/64x64"></a>
										<div class="media-body">
											<h4 class="media-heading">Nested media heading</h4>
											Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
										</div>
									</div>
								</div>
							</div>
							<!-- Nested media object -->
							<div class="media">
								<a class="pull-left" href="#">
									<img class="media-object" data-src="holder.js/64x64"></a>
								<div class="media-body">
									<h4 class="media-heading">Nested media heading</h4>
									Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
								</div>
							</div>
						</div>
					</li>
					<li class="media">
						<a class="pull-right" href="#">
							<img class="media-object" data-src="holder.js/64x64"></a>
						<div class="media-body">
							<h4 class="media-heading">Media heading</h4>
							Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
						</div>
					</li>
				</ul>
			</div>
			<pre class="prettyprint linenums">
				&lt;ul class="media-list"&gt;
				&lt;li class="media"&gt;
				&lt;a class="pull-left" href="#"&gt;
				&lt;img class="media-object" data-src="holder.js/64x64"&gt;
				&lt;/a&gt;
				&lt;div class="media-body"&gt;
				&lt;h4 class="media-heading"&gt;Media heading&lt;/h4&gt;
				...

				&lt;!-- Nested media object --&gt;
				&lt;div class="media"&gt;
				...
				&lt;/div&gt;
				&lt;/div&gt;
				&lt;/li&gt;
				&lt;/ul&gt;
			</pre>

		</section>

		<section id="misc">
			<div class="page-header">
				<h1>
					Miscellaneous
					<small>Lightweight utility components</small>
				</h1>
			</div>

			<h2>Wells</h2>
			<p>
				Use the well as a simple effect on an element to give it an inset effect.
			</p>
			<div class="bs-docs-example">
				<div class="well">Look, I'm in a well!</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="well"&gt;
				...
				&lt;/div&gt;
			</pre>
			<h3>Optional classes</h3>
			<p>
				Control padding and rounded corners with two optional modifier classes.
			</p>
			<div class="bs-docs-example">
				<div class="well well-large">Look, I'm in a well!</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="well well-large"&gt;
				...
				&lt;/div&gt;
			</pre>
			<div class="bs-docs-example">
				<div class="well well-small">Look, I'm in a well!</div>
			</div>
			<pre class="prettyprint linenums">
				&lt;div class="well well-small"&gt;
				...
				&lt;/div&gt;
			</pre>

			<h2>Close icon</h2>
			<p>
				Use the generic close icon for dismissing content like modals and alerts.
			</p>
			<div class="bs-docs-example">
				<p>
					<button class="close" style="float: none;">&times;</button>
				</p>
			</div>
			<pre class="prettyprint linenums">&lt;button class="close"&gt;&amp;times;&lt;/button&gt;</pre>
			<p>
				iOS devices require an href="#" for click events if you would rather use an anchor.
			</p>
			<pre class="prettyprint linenums">&lt;a class="close" href="#"&gt;&amp;times;&lt;/a&gt;</pre>

			<h2>Helper classes</h2>
			<p>
				Simple, focused classes for small display or behavior tweaks.
			</p>

			<h4>.pull-left</h4>
			<p>Float an element left</p>
			<pre class="prettyprint linenums">class="pull-left"</pre>
			<pre class="prettyprint linenums">
					.pull-left {
					float: left;
				}
			</pre>

			<h4>.pull-right</h4>
			<p>Float an element right</p>
			<pre class="prettyprint linenums">class="pull-right"</pre>
			<pre class="prettyprint linenums">
					.pull-right {
					float: right;
				}
			</pre>

			<h4>.muted</h4>
			<p>
				Change an element's color to
				<code>#999</code>
			</p>
			<pre class="prettyprint linenums">class="muted"</pre>
			<pre class="prettyprint linenums">
					.muted {
					color: #999;
				}
			</pre>

			<h4>.clearfix</h4>
			<p>
				Clear the
				<code>float</code>
				on any element
			</p>
			<pre class="prettyprint linenums">class="clearfix"</pre>
			<pre class="prettyprint linenums">
				.clearfix {
					*zoom: 1;
						&:before,
						&:after {
							display: table;
							content: "";
								}
						&:after {
							clear: both;
						}
				}
			</pre>

		</section>

	</div>
</div>

</div>

<?php endwhile; ?>
<?php get_footer(); ?>